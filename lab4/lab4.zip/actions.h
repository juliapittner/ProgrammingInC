#include "structs.h"

#ifndef ACTIONS_H
#define ACTIONS_H
void fight_back(struct Sim *sim_ptr);

int continue_fight(struct Sim *sim_ptr);
#endif
