
/* alternative memory calls (both reliable and unreliable use these) */
void *alternative_calloc(size_t nmemb, size_t size);
void *alternative_malloc(size_t size);
void alternative_free(void *ptr );

