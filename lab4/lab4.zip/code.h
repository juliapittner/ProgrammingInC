/* Julia Pittner */

int alien_color(unsigned int alien_code);

int alien_type(unsigned int alien_code);

int alien_points(unsigned int alien_code);

unsigned int extract_bits(int number, int number_bits, int position);

int check_elapsed_time(double ET, double delta_time);
