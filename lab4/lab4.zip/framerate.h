/* Julia Pittner */

#define DT 0.03125
#define SIMDELAY 4
