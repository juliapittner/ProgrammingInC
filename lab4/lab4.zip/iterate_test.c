/*Julia Pittner*/

#include "node.h"
#include <stdio.h>



int main()
{
	
	int len;
	struct Node *head = NULL;
	printf("Enter the length of list: ");
	scanf("%d", &len);


	
	

	for(i = 0; i < len; i++)
	{
		struct Node *temp = malloc(sizeof(*temp));

		temp->data = i;
		temp->next = head;
		head = temp;

	}

	while(temp != NULL)
	{

		printf("%d\n", temp->data);
		temp = temp->next;

	}
}
