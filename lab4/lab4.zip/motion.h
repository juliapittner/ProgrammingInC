/* Julia Pittner */

double change_X(double X, double VX, double delta_time);

double change_VX(int A, double X, double Y, double VX);

double change_Y(double X, double Y, double VY, double delta_time, unsigned int code);
