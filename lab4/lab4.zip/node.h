typedef struct Node{
	struct Node *next;
	void *data;
	}Node;
